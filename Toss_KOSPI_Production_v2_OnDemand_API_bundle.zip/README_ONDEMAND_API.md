# 종목코드 + 기준일 온디맨드 차트/CNN API

## 요청이 처리되는 방식

프런트엔드가 다음 값을 보냅니다.

```json
{
  "symbol": "005930",
  "asOf": "2023-08-14",
  "periods": [6, 12],
  "predict": true
}
```

서버는 다음 두 구간을 계산합니다.

- 6M: 2023-02-15 ~ 2023-08-14
- 12M: 2022-08-15 ~ 2023-08-14

종목코드는 `005930`처럼 보내는 것이 권장되지만 `5930`이나 숫자 `5930`을
보내도 서버가 `005930`으로 보정합니다.

종료일을 포함하면서 `시작일 + N개월 - 1일 = 종료일`이 되도록 계산한 것입니다.
기준일이 주말이나 휴장일이어도 오류로 처리하지 않고, 그 날짜 이전의 마지막 실제
거래일까지 사용합니다. 주말·휴장일 행이나 보간 가격은 만들지 않습니다.

각 구간의 실제 일봉이 100개 이상이면 전체를 연속 OHLC 100캔들로 집계하고 기존과
동일한 흑백 이미지를 만듭니다. 같은 종목·날짜·기간 요청은 디스크 캐시를 재사용합니다.

## 파일 구성

- `toss_kospi_ondemand_api.py`: FastAPI 서버
- `toss_kospi_production_pipeline.py`: 토스 수집·100캔들·이미지·CNN 공통 코드
- `requirements-ondemand-api.txt`: Python 패키지
- `.env.ondemand.example`: 환경변수 예시
- `Dockerfile.ondemand`: CPU 서버 배포 예시

## 로컬 또는 서버 실행

Python 3.11 이상 환경에서 실행합니다.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-ondemand-api.txt
pip install torch
```

`.env.ondemand.example`을 참고해 환경변수를 설정한 뒤 실행합니다. `.env` 파일을
자동으로 읽는 코드는 넣지 않았으므로 운영 플랫폼의 Secret 기능이나 셸 환경변수를
사용하세요.

```bash
uvicorn toss_kospi_ondemand_api:app --host 0.0.0.0 --port 8000 --workers 1
```

실행 후 아래 주소에서 API 입력 형식과 테스트 화면을 볼 수 있습니다.

```text
http://localhost:8000/docs
```

## 요청 예시

`APP_API_KEY`를 설정했다면 `POST /v1/analyze`에 반드시 `X-API-Key`를 보냅니다.

```bash
curl -X POST http://localhost:8000/v1/analyze \
  -H "Content-Type: application/json" \
  -H "X-API-Key: 서비스용-API-키" \
  -d '{
    "symbol": "005930",
    "asOf": "2023-08-14",
    "periods": [6, 12],
    "predict": true
  }'
```

모델 연결 전 이미지 생성만 확인하려면 다음처럼 요청합니다.

```json
{
  "symbol": "005930",
  "asOf": "2023-08-14",
  "periods": [6, 12],
  "predict": false
}
```

## 응답 예시

```json
{
  "requestId": "f81dbe1b17d41955",
  "symbol": "005930",
  "name": "삼성전자",
  "market": "KOSPI",
  "asOf": "2023-08-14",
  "requestedPeriods": ["6M", "12M"],
  "targetCandles": 100,
  "adjusted": true,
  "cached": false,
  "results": [
    {
      "period": "6M",
      "periodStart": "2023-02-15",
      "periodEnd": "2023-08-14",
      "firstTradingDay": "2023-02-15",
      "lastTradingDay": "2023-08-14",
      "sourceBars": 123,
      "candles": 100,
      "status": "ok",
      "imageUrl": "http://localhost:8000/v1/images/005930/2023-08-14/6M.png",
      "candleUrl": "http://localhost:8000/v1/candles/005930/2023-08-14/6M.csv",
      "prediction": {
        "predictedIndex": 20,
        "predictedLabel": "class_20",
        "confidence": 0.82,
        "topK": [
          {"rank": 1, "index": 20, "label": "class_20", "confidence": 0.82},
          {"rank": 2, "index": 7, "label": "class_7", "confidence": 0.11}
        ]
      }
    }
  ]
}
```

`sourceBars`는 해당 달력 구간에 실제로 존재한 일봉 수입니다. 신규 상장이나 장기
거래정지 때문에 100개보다 적으면 그 기간은 `insufficient_data`로 반환하고 가짜
캔들을 만들지 않습니다.

## 프런트엔드 연결 예시

```javascript
const response = await fetch(`${API_BASE_URL}/v1/analyze`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": APP_API_KEY,
  },
  body: JSON.stringify({
    symbol: "005930",
    asOf: "2023-08-14",
    periods: [6, 12],
    predict: true,
  }),
});

if (!response.ok) {
  throw new Error(await response.text());
}

const data = await response.json();
const sixMonth = data.results.find((item) => item.period === "6M");

// React 예: <img src={sixMonth.imageUrl} alt="6개월 주가 차트" />
```

`APP_API_KEY`는 분석 연산을 보호합니다. 응답의 이미지/CSV URL은 브라우저의 `<img>`
태그와 다운로드 링크에서 바로 쓸 수 있도록 별도 헤더 없이 읽게 되어 있습니다.
이미지까지 비공개로 해야 한다면 프런트엔드 서버가 파일을 프록시하거나 별도의 서명
URL 계층을 추가하세요.

## 기존 상위 500개 목록만 허용하기

배치 파이프라인에서 생성된 다음 파일의 경로를 지정합니다.

```text
UNIVERSE_CSV=/data/kospi_current_top500.csv
```

이 값이 있으면 CSV에 포함된 종목만 분석합니다. 400개 또는 300개로 제한하려면 해당
실행에서 생성된 `kospi_current_top400.csv`, `kospi_current_top300.csv`를 지정합니다.
비워두면 현재 ACTIVE KOSPI 보통주 전체를 대상으로 토스 API에서 종목을 검증합니다.

## 모델 연결

권장 설정은 TorchScript입니다.

```text
MODEL_PATH=/models/chart_classifier_scripted.pt
MODEL_FORMAT=torchscript
CLASS_NAMES_PATH=/models/class_to_idx.json
```

다음 설정은 학습 DataLoader와 정확히 같아야 합니다.

- `MODEL_IMAGE_HEIGHT`, `MODEL_IMAGE_WIDTH`
- `MODEL_INPUT_CHANNELS`: 비우면 첫 Conv2d에서 자동 감지, 또는 1/3
- `MODEL_MEAN`, `MODEL_STD`: Normalize를 안 했다면 둘 다 빈 값
- `CLASS_NAMES_PATH`: 학습 당시 `class_to_idx.json`

`state_dict`를 사용하려면 모델 구조를 반환하는 함수를 만들고 다음처럼 지정합니다.

```text
MODEL_FORMAT=state_dict
MODEL_BUILDER=my_model:build_model
```

## Docker 실행

```bash
docker build -f Dockerfile.ondemand -t kospi-chart-api .

docker run --rm -p 8000:8000 \
  --env-file .env.ondemand \
  -v "$(pwd)/model:/models:ro" \
  -v "$(pwd)/ondemand_storage:/data" \
  kospi-chart-api
```

컨테이너 환경에서는 `MODEL_PATH=/models/chart_classifier_scripted.pt`처럼 컨테이너
내부 경로를 사용해야 합니다.

## 실제 배포 시 중요한 점

- Colab은 런타임이 종료되고 외부 IP가 바뀌므로 공개 API 서버로는 적합하지 않습니다.
- 토스증권 WTS 허용 IP에는 배포 서버의 **고정 outbound IPv4**를 등록해야 합니다.
- 생성 결과를 유지하려면 `STORAGE_ROOT`를 영구 디스크나 볼륨에 연결하세요.
- 서버 코드는 한 프로세스 안에서 렌더링과 모델 추론을 직렬화합니다. 기본 worker는
  1개이며 학술제 규모에 적합합니다. 트래픽이 커지면 작업 큐·Redis·공유 오브젝트
  스토리지와 별도 추론 worker 구조로 확장하세요.
- `TOSS_CLIENT_SECRET`, `APP_API_KEY`는 플랫폼 Secret에 저장하고 Git이나 프런트엔드
  번들에 넣지 마세요. 브라우저에 `APP_API_KEY`를 직접 넣으면 사용자가 볼 수 있으므로,
  실제 서비스에서는 프런트엔드 서버가 이 API를 대신 호출하는 구조가 더 안전합니다.
