# KOSPI 상위 N개 6M/12M 차트 + CNN 추론 파이프라인

## 무엇을 처리하는가

- 토스증권 Open API의 종목·시세 endpoint만 사용합니다. 계좌, 잔고, 주문 API는 호출하지 않습니다.
- 현재 KOSPI ACTIVE 보통주를 `발행주식수 × 현재가`로 정렬해 상위 N개를 고릅니다.
- 각 종목의 2016년 이후 수정 일봉을 받아 정확한 달력 기준 6개월·12개월 구간을 만듭니다.
- 각 구간 안의 실제 거래일만 사용해 연속 OHLC 100캔들로 집계합니다.
- 주말·휴장일을 만들거나 가격을 보간하지 않습니다.
- 흰 배경·검정 캔들·축/격자 없음의 흑백 PNG를 생성합니다.
- 생성 이미지 전체를 PyTorch CNN으로 추론해 CSV와 웹용 JSON으로 저장합니다.

현재 진행 중인 반기·연도는 제외됩니다. 예를 들어 2026년 8월에 실행하면 6M은
2026년 1~6월까지, 12M은 2025년 1~12월까지 생성됩니다.

## Colab 실행 순서

1. `Toss_KOSPI_Production_CNN_Colab.ipynb`를 Colab에서 엽니다.
2. 첫 설치 셀을 실행합니다.
3. `toss_kospi_production_pipeline.py`를 업로드합니다.
4. Colab Secrets에 `TOSS_CLIENT_ID`, `TOSS_CLIENT_SECRET`을 등록하고 Notebook access를 켭니다.
5. 토큰 발급이 403이면 IP 확인 셀의 IPv4를 토스증권 WTS 허용 IP에 등록합니다.
6. `TOP_N`, 필요하면 `RANK_START`와 `RANK_END`를 설정하고 수집 셀을 실행합니다.
7. Drive의 `toss_kospi_production/model/`에 학습 모델과 클래스 매핑을 넣습니다.
8. 학습 당시 전처리 값을 확인한 뒤 CNN 추론 셀을 실행합니다.

## 500개를 400개 또는 300개로 바꾸는 곳

노트북의 `규모·분할 실행·저장 위치 설정` 셀에서 아래 한 줄만 바꿉니다.

```python
TOP_N = 500  # 400 또는 300
```

`RANK_END = TOP_N`, `PipelineConfig(top_n=TOP_N)`, `OUTPUT_ROOT`가 이 값을 따라가므로
다른 곳을 고칠 필요가 없습니다. 원본 일봉은 `shared_cache/raw_daily/`에 있어 500개
실행 후 400개나 300개로 바꾸어도 해당 종목의 다운로드 파일을 재사용합니다.

## Colab 중단에 대비한 분할 실행

상위 500개는 API 요청과 이미지 렌더링 양이 많습니다. 한 번에 실행할 수도 있지만,
런타임이 불안정하면 같은 `TOP_N`과 `OUTPUT_ROOT`를 유지한 채 다음처럼 나눕니다.

```python
# 첫 번째 실행
RANK_START = 1
RANK_END = 100

# 다음 실행에서 이 두 값만 변경
RANK_START = 101
RANK_END = 200
```

종목 하나가 끝날 때마다 체크포인트가 저장됩니다. 같은 범위를 다시 실행해도 정상
파일이 남아 있는 완료 종목은 건너뜁니다. 분할 작업이 모두 끝나기 전에는
`all top-N symbols produced images` 검사가 실패하는 것이 정상입니다.

첫 실행의 시가총액 순위는 CSV 스냅샷으로 고정되어 여러 날에 걸친 분할 실행에서도
대상이 바뀌지 않습니다. 새 기준일의 종목 순위를 만들 때는 새 `OUTPUT_ROOT`를 쓰는
것을 권장합니다. 같은 위치에서 강제로 갱신하려면 `refresh_universe=True`를 사용할 수
있지만, 연구 결과의 기준일을 명확하게 기록해야 합니다.

## 학습 모델을 연결할 때 반드시 같은 네 가지

다음 값은 학습 DataLoader와 추론에서 완전히 같아야 합니다.

1. `IMAGE_SIZE`: 예를 들어 `(224, 224)` 또는 `(256, 256)`
2. `INPUT_CHANNELS`: 흑백 1채널 또는 RGB 복제 3채널
3. `NORMALIZE_MEAN`, `NORMALIZE_STD`: 학습 때 Normalize를 안 했다면 둘 다 `None`
4. `class_to_idx.json`: 출력 뉴런 인덱스와 클래스 이름의 정확한 순서

`class_to_idx.json`은 학습 시 `ImageFolder`에서 다음처럼 저장해 두는 것이 안전합니다.

```python
import json

with open('class_to_idx.json', 'w', encoding='utf-8') as file:
    json.dump(train_dataset.class_to_idx, file, ensure_ascii=False, indent=2)
```

파일 형식 예시는 다음과 같습니다.

```json
{
  "class_0": 0,
  "class_1": 1,
  "class_20": 20
}
```

## 권장 모델 저장 형식

TorchScript는 추론 노트북에 모델 클래스 코드를 다시 붙이지 않아도 됩니다.
학습을 마친 직후 다음과 같이 저장할 수 있습니다.

```python
model.eval()
scripted_model = torch.jit.script(model.cpu())
scripted_model.save('chart_classifier_scripted.pt')
```

이 파일을 Drive의 아래 위치에 둡니다.

```text
MyDrive/toss_kospi_production/model/chart_classifier_scripted.pt
```

`state_dict`만 있다면 노트북에서 `MODEL_FORMAT='state_dict'`로 바꾸고, 학습 때와
동일한 모델 구조를 반환하는 `MODEL_BUILDER`를 지정해야 합니다. 체크포인트만 보고
임의의 CNN 구조를 복원하는 것은 불가능합니다.

## 웹 연결용 결과

`OUTPUT_ROOT/inference/` 아래에 다음 파일이 생깁니다.

- `predictions_all.csv`: 모든 기간의 예측과 Top-K
- `predictions_latest.csv`: 종목·6M/12M별 최신 한 건
- `prediction_summary.csv`: 클래스별 이미지 수와 평균 확률
- `web_results_latest.json`: 웹 백엔드가 읽기 쉬운 최신 결과
- `inference_settings.json`: 크기, 채널, 정규화, 클래스 순서 기록

웹 서버에서 `OUTPUT_ROOT`를 정적 파일 루트로 제공하면 JSON의
`imageRelativePath`로 해당 PNG를 연결할 수 있습니다. 절대 `imagePath`는 Colab
Drive 내부 확인용입니다.

## 연구 해석 시 주의

이 파이프라인은 **현재** 시가총액 상위 종목을 고른 뒤 과거 차트를 생성합니다.
따라서 과거 각 시점의 실제 상위 N개 구성종목을 재현한 것이 아니며 생존편향이
있습니다. 학술제 보고서에는 “실행 기준일 현재 KOSPI 보통주 상위 N개”라고 적는 것이
정확합니다. 과거 시점별 구성종목 연구가 필요하면 별도의 역사적 종목·시가총액
데이터가 필요합니다.
